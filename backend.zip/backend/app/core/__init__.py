# Core configuration package

